<import resource="classpath:/alfresco/templates/webscripts/org/alfresco/slingshot/documentlibrary/action/action.lib.js">

/**
 * Backup multiple files action
 * @method POST
 */

/**
 * Entrypoint required by action.lib.js
 *
 * @method runAction
 * @param p_params {object} Object literal containing files array
 * @return {object|null} object representation of action results
 */
function runAction(p_params)
{
   var results = [];
   var files = p_params.files;
   var file, fileNode, result, nodeRef;

   logger.log("fileNode :" + fileNode);
   
   // Must have array of files
   if (!files || files.length == 0)
   {
      status.setCode(status.STATUS_BAD_REQUEST, "No files.");
      return;
   }

   for (file in files)
   {
      nodeRef = files[file];
      result =
      {
         nodeRef: nodeRef,
         action: "publishFile",
         success: false,
         isContainer : false
      }

      try
      {
         fileNode = search.findNode(nodeRef);
         
         if (fileNode === null)
         {
            result.id = file;
            result.nodeRef = nodeRef;
            result.success = false;
         }
         else
         {
            result.id = fileNode.name;
            result.type = fileNode.isContainer ? "folder" : "document";
            result.isContainer = fileNode.isContainer;
            
            if(!fileNode.isContainer){
                // copy the node to the backup folder
                fileNode.addAspect("sc:webable"); //oops, this should be webable.
                result.success = true;
                logger.info("sc:webable aspect added.");
            }else{
            	status.setCode(status.STATUS_BAD_REQUEST, "Folders can't be published.");
            	result.success = false;
            	throw "Folders can't be published.";
            }
            
         }
      }
      catch (e)
      {
         result.id = file;
         result.nodeRef = nodeRef;
         result.success = false;
      }

      results.push(result);
   }

   return results;
}

/* Bootstrap action script */
main();
